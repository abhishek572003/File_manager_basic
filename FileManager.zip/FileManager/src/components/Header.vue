<template>
  <header class="head">
    <b-navbar type="dark" variant="primary" toggleable>
      <b-navbar-brand href="#">
        <font-awesome-icon icon="tasks" />&nbsp; &nbsp; File Manager
      </b-navbar-brand>
      <b-navbar-nav class="ml-auto">
        <b-nav-item>Download</b-nav-item>
      </b-navbar-nav>
    </b-navbar>
  </header>
</template>

<script>
export default {
  data() {
    return {};
  }
};
</script>
<style scoped>
</style>
