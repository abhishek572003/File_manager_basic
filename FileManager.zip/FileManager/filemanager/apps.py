from django.apps import AppConfig


class FilemanagerConfig(AppConfig):
    name = 'filemanager'
